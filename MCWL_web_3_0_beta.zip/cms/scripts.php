<?php

final class scripts{
    
    public static function getAllScriptsInfo(){
        return parse_ini_file("cms/scripts.ini", true);
    }
    
}