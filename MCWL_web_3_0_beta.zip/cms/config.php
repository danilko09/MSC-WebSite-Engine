<?php

class Config{

	const db_pref = "";
	const db_host = "localhost";
	const db_user = "root";
	const db_pass = "";
	const db_name = "";
	const site_url = "http://localhost";
	const debug = true;
	const site_name = "Local testing site";

}