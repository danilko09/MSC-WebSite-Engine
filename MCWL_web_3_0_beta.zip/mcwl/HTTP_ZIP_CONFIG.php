<?php

$file = "client.zip";