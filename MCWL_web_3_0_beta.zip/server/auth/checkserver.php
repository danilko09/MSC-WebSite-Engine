<?php
//Подключение файлов CMS
chdir("../..");//Смена директории | на всякий случай
include("cms/config.php");
include("cms/lib.php");
//Сам скрипт | подгрузка библиотеки БД
$db = libs::getLib("database");
//Сам скрипт | определение переменных
$user = $_GET['user'];
$serverid = $_GET['serverId'];
//Получение ID сервера
$result = $db->getField("servers","server","login",$user);
//Проверка ID
if($result === $serverid){
    echo "YES";
} else{
    echo "NO";
}
?>