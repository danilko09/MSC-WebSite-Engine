<?php
//Подключение файлов CMS
chdir("../..");//Смена директории | на всякий случай
include("cms/config.php");
include("cms/lib.php");
//Сам скрипт | подгрузка библиотеки БД
$db = libs::getLib("database");
//Сам скрипт | определение переменных
$sessionid = $_GET['sessionId'];
$user = $_GET['user'];
$serverid = $_GET['serverId'];
//Проверка сессии и запись сервера
if($db->getField("sessions","session","login",$user) == $sessionid){
	if(!$db->isExists("servers","login",$login))$db->insert("server",array("login"=>$login,"server"=>$serverid));
	else $db->setField("servers", "server", $serverid, "login", $login);
	echo "OK";
}else{
	echo "Bad login";
}
?>