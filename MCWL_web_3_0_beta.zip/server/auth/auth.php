<?php
//Подключение файлов CMS
chdir("../..");//Смена директории | для библиотек нужно
include("cms/config.php");
include("cms/lib.php");
//Сам скрипт | подгрузка библиотек
$db = libs::getLib("database");
if(libs::LoadLib("users")) $users = libs::getLib("users");
else die("no users lib");
//Определение переменных
$login=$_POST['user'];
$password=$_POST['password'];
$ver=$_POST['version'];
//Проверка версии
if($db->getField("server","value","param","launcher") == $ver){
	//Проверка пароля и логина
	if ($users->VerifiLogin($login,$password)) 
	{
		//Генерация сессии и получение билда
		$sessid = generateSessionId();
		$gamebuild=$db->getField("server","value","param","build");
		//Обновление сессии в БД
		if(!$db->isExists("sessions","login",$login))$db->insert("sessions",array("login"=>$login,"session"=>$sessid));
		else $db->setField("sessions", "session", $sessid, "login", $login);
		//Генерация тикета на загрузку и выдача результата
		$dlticket = md5($login);
		echo $gamebuild.':'.$dlticket.':'.$login.':'.$sessid.':';
	}else{
		//В случае не верного логина\пароля
		echo "Bad login";
	}
}else{
	//В случае, если лаунчер у старел(версия в запросе не совпала с текущей из БД)
	echo 'Old version';
}
		
function generateSessionId(){
    // generate rand num
    srand(time());
    $randNum = rand(1000000000, 2147483647).rand(1000000000, 2147483647).rand(0,9);
    return $randNum;
}
?>