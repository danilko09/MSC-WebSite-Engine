<?php

	next_stage();

?>