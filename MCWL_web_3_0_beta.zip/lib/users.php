<?php

class users{

	public function IsAuthorized(){
                return (isset($_SESSION['auth']) && $_SESSION['auth'] == "1" && $_SESSION['login'] != null && $_SESSION['login'] != "") ? "1" : "0";
	}
	
	public function GetLogin(){	
		return isset($_SESSION['login']) ? $_SESSION['login'] : null;
	}
	public function GetGroup(){
                return (!isset($_SESSION['login']) || $_SESSION['login'] == "" || $_SESSION['login'] == null) ? "guest" 
                : libs::GetLib("database")->GetField("users","group","login",$_SESSION['login']);		
	}
	
	public function GetLoginForm(){
	
		return str_replace("[method]", "POST", libs::GetLib("templates")->GetTmpl("auth/login-form"));
	
	}
	
	public function GetRegisterForm(){
		return str_replace("[method]", "POST", libs::GetLib("templates")->GetTmpl("auth/register-form"));
	}
	
	public function TryLogin(){
            $ok = (filter_input(INPUT_POST,'login') != null && libs::GetLib("database")->getField("users", "password", "login", filter_input(INPUT_POST,'login')) == filter_input(INPUT_POST,'password'));
	    if($ok){
                $_SESSION['login'] = filter_input(INPUT_POST,'login');
                $_SESSION['auth'] = true;
                $_SESSION['group'] = "user";
                return true;
            }else{$_SESSION['auth'] = "0";}
        }
	
	public function VerifiLogin($login,$pass){
		$ok = ($login != "" && $login != "" && libs::GetLib("database")->getField("users", "password", "login", $login) == $pass);
                if($ok){
			$_SESSION['login'] = $login;
			$_SESSION['auth'] = true;
			$_SESSION['group'] = "user";
		}
                return $ok;
	}
	
	public function TryRegister(){
	
		$ok = (filter_input(INPUT_POST,'login') != "" && filter_input(INPUT_POST,'login') != "" && libs::GetLib("database")->getField("users", "password", "login", filter_input(INPUT_POST,'login')) == filter_input(INPUT_POST,'password'));
		
                if($ok){return "����� �����.";}
		elseif(filter_input(INPUT_POST,'mail') != null){
			$user['login'] = filter_input(INPUT_POST,'login');
			$user['password'] = filter_input(INPUT_POST,'password');
			$user['mail'] = filter_input(INPUT_POST,'mail');
			$user['group'] = "registred";
			libs::GetLib("database")->insert("users",$user);
			return "ok";
		}
		
	
	}
	
	public function LogOut(){
		unset($_SESSION['auth']);
		unset($_SESSION['login']);
	}

}